package Converter.JDBCconnection;
/*
 * 1. Register JDBC driver(1. forName(), 2.DriverManager.registerDriver)
 * 2. Create Connection Object(URL, Username, Password)
 * 3. create statement Object(1. JDBC Statement, 2. Collable Statement, 3. Prepared Statement) 
 * 4. Execute Query
 * 5. Close Connection
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCConnection {

	public static void main(String[] args) {
		
		try
		{
			System.out.println("Welcome to JDBC!!");
			 String driver ="com.mysql.jdbc.Driver";
			 
			 String url="jdbc:mysql://localhost:3306/jfs";
			 String username ="root";
			 String password="Priya@123";
			 
			 String query = "select ename from emp where ID=1002";
			 Class.forName(driver);
			 
			 //Connection
			 Connection con = DriverManager.getConnection(url,username,password);// Connection Object
			 System.out.println("Connection Created Succesfully!!");
			
			 Statement st = con.createStatement();// Create Statement
			 
			 ResultSet rs = st.executeQuery(query);
			 
			 rs.next();
			 String name=rs.getString("ename");
			 System.out.println(name);
			 
			 st.close();
			 con.close();
			 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	private static ResultSet executeQuery(String query) {
		// TODO Auto-generated method stub
		return null;
	}

}
